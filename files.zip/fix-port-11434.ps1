# Fix Port 11434 Conflict - PowerShell Version
# This script finds and kills the process using port 11434

Write-Host ""
Write-Host "===================================================" -ForegroundColor Cyan
Write-Host "     Port 11434 Conflict Resolver" -ForegroundColor Cyan
Write-Host "===================================================" -ForegroundColor Cyan
Write-Host ""

Write-Host "[1] Checking what's using port 11434..." -ForegroundColor Yellow
Write-Host ""

# Get the process using port 11434
$connection = Get-NetTCPConnection -LocalPort 11434 -ErrorAction SilentlyContinue

if ($connection) {
    $processId = $connection.OwningProcess
    $process = Get-Process -Id $processId -ErrorAction SilentlyContinue
    
    Write-Host "Found process using port 11434:" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  Process Name: " -NoNewline
    Write-Host $process.ProcessName -ForegroundColor Cyan
    Write-Host "  Process ID:   " -NoNewline
    Write-Host $processId -ForegroundColor Cyan
    Write-Host "  Path:         " -NoNewline
    Write-Host $process.Path -ForegroundColor Cyan
    Write-Host ""
    
    # Check if it's Ollama (common conflict)
    if ($process.ProcessName -like "*ollama*") {
        Write-Host "⚠️  This is Ollama!" -ForegroundColor Red
        Write-Host "   Ollama uses port 11434 by default." -ForegroundColor Yellow
        Write-Host "   You have two options:" -ForegroundColor Yellow
        Write-Host "   1. Kill Ollama (recommended if you're not using it)" -ForegroundColor Yellow
        Write-Host "   2. Change tui-listener port (edit CONFIG.bridgePort in tui-listener.js)" -ForegroundColor Yellow
        Write-Host ""
    }
    
    # Check if it's already tui-listener
    if ($process.ProcessName -eq "node" -and $process.Path -like "*node.exe*") {
        Write-Host "⚠️  This appears to be a Node.js process" -ForegroundColor Yellow
        Write-Host "   It might be tui-listener already running in another terminal." -ForegroundColor Yellow
        Write-Host "   Check your other terminals before killing." -ForegroundColor Yellow
        Write-Host ""
    }
    
    $confirmation = Read-Host "Kill this process? (Y/N)"
    
    if ($confirmation -eq 'Y' -or $confirmation -eq 'y') {
        Write-Host ""
        Write-Host "[2] Killing process $processId..." -ForegroundColor Yellow
        
        try {
            Stop-Process -Id $processId -Force
            Write-Host ""
            Write-Host "✓ Process killed successfully!" -ForegroundColor Green
            Write-Host ""
            Write-Host "[3] Port 11434 is now available" -ForegroundColor Green
            Write-Host ""
            Write-Host "You can now start tui-listener:" -ForegroundColor Cyan
            Write-Host "  node tui-listener.js" -ForegroundColor White
        }
        catch {
            Write-Host ""
            Write-Host "✗ Failed to kill process: $_" -ForegroundColor Red
            Write-Host "  Try running PowerShell as Administrator" -ForegroundColor Yellow
        }
    }
    else {
        Write-Host ""
        Write-Host "Cancelled. Process not killed." -ForegroundColor Yellow
    }
}
else {
    Write-Host "✓ Port 11434 is available! No process using it." -ForegroundColor Green
    Write-Host ""
    Write-Host "You can start tui-listener now:" -ForegroundColor Cyan
    Write-Host "  node tui-listener.js" -ForegroundColor White
}

Write-Host ""
Write-Host "===================================================" -ForegroundColor Cyan
Write-Host ""
